package com.dataoneio.app.model;

import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Cascade;

/**
 * The Class Movie. A movie has the following attributes: Id Name (required)
 * Cover image url Release date (required) Genre Lead Actors/Actresses (should
 * be a many-to-many connection to actors table in the database) (required)
 * Director (should be a one-to-many connection to director table in database)
 * (required)
 */
@Entity
public class Movie {

  /** The id. */
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;

  /** The name. */
  private String name;

  /** The img url. */
  private String imgUrl;

  /** The release date. */
  private Date releaseDate;

  /** The genre. */
  private String genre;

  /** The list actors. */
  @ManyToMany(cascade = CascadeType.ALL)
  @JoinTable(name = "movie_actor", joinColumns = @JoinColumn(name = "movie_id", 
  referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "actor_id", 
  referencedColumnName = "id"))
 
  private List<Actor> listActors;

  /** The list directors. */
  @OneToOne
  @JoinColumn(name="director_Id",nullable = false, referencedColumnName = "id")
 /* @JoinColumn(name = "director_Id", nullable = false, referencedColumnName = "id")*/
  private Director director;

  /**
   * Gets the id.
   *
   * @return the id
   */
  public Long getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id
   *          the new id
   */
  public void setId(Long id) {
    this.id = id;
  }

  /**
   * Gets the name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Sets the name.
   *
   * @param name
   *          the new name
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Gets the img url.
   *
   * @return the img url
   */
  public String getImgUrl() {
    return imgUrl;
  }

  /**
   * Sets the img url.
   *
   * @param imgUrl
   *          the new img url
   */
  public void setImgUrl(String imgUrl) {
    this.imgUrl = imgUrl;
  }

  /**
   * Gets the release date.
   *
   * @return the release date
   */
  public Date getReleaseDate() {
    return releaseDate;
  }

  /**
   * Sets the release date.
   *
   * @param releaseDate
   *          the new release date
   */
  public void setReleaseDate(Date releaseDate) {
    this.releaseDate = releaseDate;
  }

  /**
   * Gets the genre.
   *
   * @return the genre
   */
  public String getGenre() {
    return genre;
  }

  /**
   * Sets the genre.
   *
   * @param genre
   *          the new genre
   */
  public void setGenre(String genre) {
    this.genre = genre;
  }

  /**
   * Gets the list actors.
   *
   * @return the list actors
   */
  public List<Actor> getListActors() {
    return listActors;
  }

  /**
   * Sets the list actors.
   *
   * @param listActors
   *          the new list actors
   */
  public void setListActors(List<Actor> listActors) {
    this.listActors = listActors;
  }

  /**
   * Gets the director.
   *
   * @return the director
   */
  public Director getDirector() {
    return director;
  }

  /**
   * Sets the director.
   *
   * @param director
   *          the new director
   */
  public void setDirector(Director director) {
    this.director = director;
  }

  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "Movie [id=" + id + ", name=" + name + ", imgUrl=" + imgUrl + ", releaseDate="
        + releaseDate + ", genre=" + genre + ", listActors=" + listActors + ", Director=" + director
        + "]";
  }

}
