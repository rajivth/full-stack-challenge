package com.dataoneio.app.dto;

/**
 * The Class ReviewDto.
 */
public class ReviewDto {

  /** The id. */
  private Long id ;
  /** The name. */
  
  private String rating;

  /** The comment. */
  private String comment;

  /** The movie id. */
  private Long movieId;
  
  /**
   * Instantiates a new review dto.
   *
   * @param id the id
   * @param rating the rating
   * @param comment the comment
   * @param movieId the movie id
   */
  public ReviewDto(Long id, String rating, String comment, Long movieId) {
    super();
    this.id = id;
    this.rating = rating;
    this.comment = comment;
    this.movieId = movieId;
  }


  /**
   * Instantiates a new review dto.
   */
  public ReviewDto() {
    super();
    // TODO Auto-generated constructor stub
  }


  /**
   * Gets the rating.
   *
   * @return the rating
   */
  public String getRating() {
    return rating;
  }

  /**
   * Sets the rating.
   *
   * @param rating
   *          the new rating
   */
  public void setRating(String rating) {
    this.rating = rating;
  }

  /**
   * Gets the comment.
   *
   * @return the comment
   */
  public String getComment() {
    return comment;
  }

  /**
   * Sets the comment.
   *
   * @param comment
   *          the new comment
   */
  public void setComment(String comment) {
    this.comment = comment;
  }

  /**
   * Gets the movie id.
   *
   * @return the movie id
   */
  public Long getMovieId() {
    return movieId;
  }

  /**
   * Sets the movie id.
   *
   * @param movieId
   *          the new movie id
   */
  public void setMovieId(Long movieId) {
    this.movieId = movieId;
  }

  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "ReviewDto [rating=" + rating + ", comment=" + comment + ", movieId=" + movieId + "]";
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public Long getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(Long id) {
    this.id = id;
  }

}
