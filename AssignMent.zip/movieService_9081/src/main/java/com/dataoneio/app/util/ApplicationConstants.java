package com.dataoneio.app.util;

/**
 * The interface ApplicationConstants.
 */

public interface ApplicationConstants {

  /** The Constant UPDATE_ERROR_MSG. */
  public static final String UPDATE_ERROR_MSG = "Update Record is not found in db";

  /** The Constant SUCCESS_MSG. */
  public static final String SUCCESS_MSG = "The Record created successfully";

  /** The Constant DELETE_SUCCESS_MSG. */
  public static final String DELETE_SUCCESS_MSG = "The Record  deleted successfully";

  /** The Constant FIELD_ERROR_MESSAGE. */
  public static final String FIELD_ERROR_MESSAGE = "Validation errors of field ";

  /** The Constant SUCCESS_MSG. */
  public static final String UPDATE_MSG = "Update Record is successfully .";

  /** The Constant MOVIE_API_URL. */
  public static final String MOVIE_API_URL = "/api/movie";

  /** The Constant START_UP_MSG. */
  public static final String START_UP_MSG = "Movies service  is Up on 9081";
  
  /** The Constant ACTOR_API_URL. */
  public static final String ACTOR_API_URL = "/api/actor";

  /** The Constant HOME_URL. */
  public static final String HOME_URL = "/";

  /** The Constant DIRECTOR_API_URL. */
  public static final String DIRECTOR_API_URL = "/api/director";

  /** The Constant NOT_FOUND. */
  public static final String NOT_FOUND = "Record not found our database";

  /** The Constant REVIEW_ADD_URL. */
  public static final String REVIEW_ADD_URL = "http://localhost:9083/api/review/add";

  /** The Constant REVIEW_ADD_URL. */
  public static final String REVIEW_FINDBY_MOVIE_URL = "http://localhost:9083/api/review/findByMovie/";

  /** The Constant REVIEW_DELETE_URL. */
  public static final String REVIEW_DELETE_URL = "http://localhost:9083/api/review/delete/";

  /** The Constant REVIEW_FIND_ALL_URL. */
  public static final String REVIEW_FIND_ALL_URL = "http://localhost:9083/api/review/findAll";
}
