package com.dataoneio.app.repository;

import com.dataoneio.app.model.Actor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * The Interface ActorRepository.
 */
@Repository
public interface ActorRepository extends JpaRepository<Actor, Long> {

}
