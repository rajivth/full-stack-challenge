package com.dataoneio.app.controller;

import com.dataoneio.app.dto.UserDto;
import com.dataoneio.app.model.Director;
import com.dataoneio.app.repository.DirectorRepository;
import com.dataoneio.app.util.ApplicationConstants;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * The Class DirectorController.
 */
@RestController
@RequestMapping("/api/director")
public class DirectorController {

  /** The director repository. */
  @Autowired
  private DirectorRepository directorRepository;

  /**
   * Creates the director.
   *
   * @param directorDto the director dto
   * @return the response entity
   * @throws InstantiationException the instantiation exception
   * @throws IllegalAccessException the illegal access exception
   */
  @PostMapping("/add")
  public ResponseEntity<?> createDirector(@RequestBody final UserDto directorDto)
      throws InstantiationException, IllegalAccessException {
    ModelMapper modelMapper = new ModelMapper();
    Director director = modelMapper.map(directorDto, Director.class);
    directorRepository.save(director);
    return new ResponseEntity<String>(ApplicationConstants.SUCCESS_MSG, HttpStatus.OK);
  }

  /**
   * Update student.
   *
   * @param directorDto the director dto
   * @param id the id
   * @return the response entity
   */
  @PutMapping("/update/{id}")
  public ResponseEntity<?> updateStudent(@RequestBody final UserDto directorDto,
      @PathVariable Long id) {

    Optional<Director> directorAccountOptional = directorRepository.findById(id);

    if (!directorAccountOptional.isPresent()) {
      return new ResponseEntity<String>(ApplicationConstants.UPDATE_ERROR_MSG,
          HttpStatus.NOT_FOUND);
    }
    ModelMapper modelMapper = new ModelMapper();
    directorDto.setId(id);
    Director updateDirector = modelMapper.map(directorDto, Director.class);
    directorRepository.save(updateDirector);
    return new ResponseEntity<Director>(updateDirector, HttpStatus.OK);
  }

  /**
   * Find actors.
   *
   * @return the response entity
   */
  @GetMapping("/findAll")
  public ResponseEntity<?> findDirectors() {
    List<Director> directorsList = directorRepository.findAll();
    return new ResponseEntity<List<Director>>(directorsList, HttpStatus.OK);
  }
}
