package com.dataoneio.app.controller;

import com.dataoneio.app.dto.UserDto;
import com.dataoneio.app.model.Actor;
import com.dataoneio.app.repository.ActorRepository;
import com.dataoneio.app.util.ApplicationConstants;

import java.util.List;
import java.util.Optional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



/**
 * The Class ActorController.
 */
@RestController
@RequestMapping("/api/actor")
public class ActorController {

  /** The director repository. */
  @Autowired
  private ActorRepository actorRepository;

  /**
   * Creates the actor.
   *
   * @param personDto the person dto
   * @return the response entity
   * @throws InstantiationException the instantiation exception
   * @throws IllegalAccessException the illegal access exception
   */
  @PostMapping("/add")
  public ResponseEntity<?> createActor(@RequestBody final UserDto personDto)
      throws InstantiationException, IllegalAccessException {
    ModelMapper modelMapper = new ModelMapper();
    Actor actor = modelMapper.map(personDto, Actor.class);
    actorRepository.save(actor);
    return new ResponseEntity<String>(ApplicationConstants.SUCCESS_MSG, HttpStatus.OK);
  }

  /**
   * Update actor.
   *
   * @param personDto
   *          the person dto
   * @param id
   *          the id
   * @return the response entity
   */
  @PutMapping("/update/{id}")
  public ResponseEntity<?> updateActor(@RequestBody final UserDto personDto,
      @PathVariable Long id) {

    ModelMapper modelMapper = new ModelMapper();
    Optional<Actor> actorAccountOptional = actorRepository.findById(id);

    if (!actorAccountOptional.isPresent()) {
      return new ResponseEntity<String>(ApplicationConstants.UPDATE_ERROR_MSG,
          HttpStatus.NOT_FOUND);
    }
    Actor actor = modelMapper.map(personDto, Actor.class);
    actor.setId(id);

    actorRepository.save(actor);

    return new ResponseEntity<Actor>(actor, HttpStatus.OK);

  }
  
  /**
   * Find actors.
   *
   * @return the response entity
   */
  @GetMapping("/findAll")
  public ResponseEntity<?> findActors() {
    List<Actor> listActors = actorRepository.findAll();
    return new ResponseEntity<List<Actor>>(listActors, HttpStatus.OK);
  }

}
