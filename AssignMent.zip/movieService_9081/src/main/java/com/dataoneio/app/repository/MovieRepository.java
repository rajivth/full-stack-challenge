package com.dataoneio.app.repository;

import com.dataoneio.app.model.Movie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * The Interface MovieRepository.
 */
@Repository
public interface MovieRepository extends JpaRepository<Movie, Long> {

  /**
   * Delete actor and movie.
   *
   * @param movieId
   *          the movie id
   * @param actorId
   *          the actor id
   */
  @Modifying
  @Query(value = "delete from movie_actor lk_Tb "
      + "where lk_Tb.movie_Id=:movieId and lk_Tb.actor_Id=:actorId", nativeQuery = true)
  @Transactional
  public void deleteActorAndMovie(@Param("movieId") Long movieId, @Param("actorId") Long actorId);

  /**
   * Delete movie.
   *
   * @param movieId the movie id
   */
  @Transactional
  @Modifying
  @Query(value = "delete from movie lk_Tb "
      + "where lk_Tb.id=:movieId ", nativeQuery = true)
  public void deleteMovie(@Param("movieId") Long movieId);

}
