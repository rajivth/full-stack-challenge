package com.dataoneio.app.repository;

import com.dataoneio.app.model.Director;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * The Interface DirectorRepository.
 */
@Repository
public interface DirectorRepository extends JpaRepository<Director, Long> {

}
