package com.dataoneio.app.dto;

import com.dataoneio.app.model.Movie;
import java.util.List;


/**
 * The Class PageDtoResponse.
 */
public class PageDtoResponse {

  /** The total elements. */
  private int totalElements;
  
  /** The total pages. */
  private int totalPages;
  
  /** The size. */
  private int size;
  
  /** The number of elements. */
  private int numberOfElements;
  
  /** The list movies. */
  private List<Movie> content;

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "PageDtoResponse [totalElements=" + totalElements + ", totalPages=" + totalPages
        + ", size=" + size + ", numberOfElements=" + numberOfElements + ", listMovies=" + content
        + "]";
  }

  /**
   * Gets the total elements.
   *
   * @return the total elements
   */
  public int getTotalElements() {
    return totalElements;
  }

  /**
   * Sets the total elements.
   *
   * @param totalElements the new total elements
   */
  public void setTotalElements(int totalElements) {
    this.totalElements = totalElements;
  }

  /**
   * Gets the total pages.
   *
   * @return the total pages
   */
  public int getTotalPages() {
    return totalPages;
  }

  /**
   * Sets the total pages.
   *
   * @param totalPages the new total pages
   */
  public void setTotalPages(int totalPages) {
    this.totalPages = totalPages;
  }

  /**
   * Gets the size.
   *
   * @return the size
   */
  public int getSize() {
    return size;
  }

  /**
   * Sets the size.
   *
   * @param size the new size
   */
  public void setSize(int size) {
    this.size = size;
  }

  /**
   * Gets the number of elements.
   *
   * @return the number of elements
   */
  public int getNumberOfElements() {
    return numberOfElements;
  }

  /**
   * Sets the number of elements.
   *
   * @param numberOfElements the new number of elements
   */
  public void setNumberOfElements(int numberOfElements) {
    this.numberOfElements = numberOfElements;
  }

  /**
   * Gets the content.
   *
   * @return the content
   */
  public List<Movie> getContent() {
    return content;
  }

  /**
   * Sets the content.
   *
   * @param content the new content
   */
  public void setContent(List<Movie> content) {
    this.content = content;
  }
}
