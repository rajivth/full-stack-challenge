package com.dataoneio.app.controller;

import com.dataoneio.app.dto.MovieDto;
import com.dataoneio.app.dto.PageDtoResponse;
import com.dataoneio.app.dto.ReviewDto;
import com.dataoneio.app.model.Movie;
import com.dataoneio.app.repository.MovieRepository;
import com.dataoneio.app.util.ApplicationConstants;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

/**
 * The Class MovieController.
 */
@RestController
@RequestMapping("/api/movie")
public class MovieController {

  /** The movie repository. */
  @Autowired
  private MovieRepository movieRepository;

  /** The page max size. */
  private final int pageMaxLimit = 10;

  /** The rest template. */
  @Autowired
  private RestTemplate restTemplate;

  /**
   * Creates the movie.
   *
   * @param movieDto
   *          the movie dto
   * @param result
   *          the result
   * @return the response entity
   * @throws InstantiationException
   *           the instantiation exception
   * @throws IllegalAccessException
   *           the illegal access exception
   * @throws JsonProcessingException
   *           the json processing exception
   */
  @PostMapping("/add")
  public ResponseEntity<?> createMovie(@Valid @RequestBody final MovieDto movieDto,
      final BindingResult result)
      throws InstantiationException, IllegalAccessException, JsonProcessingException {
    Long movieId = -1L;
    ModelMapper modelMapper = new ModelMapper();
    Movie movie = modelMapper.map(movieDto, Movie.class);

    if (result.hasErrors()) {
      return new ResponseEntity<String>(
          ApplicationConstants.FIELD_ERROR_MESSAGE + result.getFieldError().getField(),
          HttpStatus.OK);
    } else {
      movie = movieRepository.save(movie);
      if (movie != null) {
        movieId = movie.getId();
      }
      // Movie Review Check First
      final String reviewFindUrl = ApplicationConstants.REVIEW_FINDBY_MOVIE_URL + movieId;
      ResponseEntity<ReviewDto> reviewDtoResp = restTemplate.getForEntity(reviewFindUrl,
          ReviewDto.class);
      ReviewDto reviewDto = null;
      // Movie Review Not Exist
      if (reviewDtoResp != null && reviewDtoResp.getBody() != null) {
        // Movie Review Exist
        reviewDto = new ReviewDto(reviewDtoResp.getBody().getId(), movieDto.getRate(),
            movieDto.getComment(), movieId);

      } else {
        reviewDto = new ReviewDto(-1L, movieDto.getRate(), movieDto.getComment(), movieId);
      }
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      HttpEntity<ReviewDto> entity = new HttpEntity<ReviewDto>(reviewDto, headers);
      restTemplate.postForObject(ApplicationConstants.REVIEW_ADD_URL, entity, String.class);

      return new ResponseEntity<String>(ApplicationConstants.SUCCESS_MSG, HttpStatus.OK);
    }

  }

  /**
   * Update movie.
   *
   * @param movieDto
   *          the movie dto
   * @param id
   *          the id
   * @return the response entity
   * @throws InstantiationException
   *           the instantiation exception
   * @throws IllegalAccessException
   *           the illegal access exception
   */
  @PutMapping("/update/{id}")
  public ResponseEntity<?> updateMovie(@RequestBody final MovieDto movieDto,
      @PathVariable final Long id) throws InstantiationException, IllegalAccessException {

    Optional<Movie> movieAccountObj = movieRepository.findById(id);

    if (!movieAccountObj.isPresent()) {
      return new ResponseEntity<String>(ApplicationConstants.UPDATE_ERROR_MSG,
          HttpStatus.NOT_FOUND);
    }
    ModelMapper modelMapper = new ModelMapper();
    movieDto.setId(id);
    Movie updateMovie = modelMapper.map(movieDto, Movie.class);
    movieRepository.save(updateMovie);
    return new ResponseEntity<Movie>(updateMovie, HttpStatus.OK);
  }

  /**
   * Delete movie.
   *
   * @param id
   *          the id
   * @return the response entity
   * @throws InstantiationException
   *           the instantiation exception
   * @throws IllegalAccessException
   *           the illegal access exception
   */
  @DeleteMapping("/delete/{id}")
  public ResponseEntity<?> deleteMovie(@PathVariable final Long id)
      throws InstantiationException, IllegalAccessException {

    Optional<Movie> movieAccountObj = movieRepository.findById(id);

    if (!movieAccountObj.isPresent()) {
      return new ResponseEntity<String>(ApplicationConstants.UPDATE_ERROR_MSG,
          HttpStatus.NOT_FOUND);
    }

    // Movie Review Delete First
    final String reviewFindUrl = ApplicationConstants.REVIEW_DELETE_URL
        + movieAccountObj.get().getId();
    restTemplate.delete(reviewFindUrl);
    movieAccountObj.get().getListActors().forEach(actor -> {
      movieRepository.deleteActorAndMovie(movieAccountObj.get().getId(), actor.getId());
    });
    movieRepository.deleteMovie(id);
    return new ResponseEntity<String>(ApplicationConstants.DELETE_SUCCESS_MSG, HttpStatus.OK);
  }

  /**
   * Delete movie.
   *
   * @param id
   *          the id
   * @return the response entity
   * @throws InstantiationException
   *           the instantiation exception
   * @throws IllegalAccessException
   *           the illegal access exception
   * @throws JsonParseException
   *           the json parse exception
   * @throws JsonMappingException
   *           the json mapping exception
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   */
  @GetMapping("/find/{id}")
  public ResponseEntity<?> getMovie(@PathVariable final Long id) throws InstantiationException,
      IllegalAccessException, JsonParseException, JsonMappingException, IOException {

    Optional<Movie> movieAccountObj = movieRepository.findById(id);

    if (!movieAccountObj.isPresent()) {
      return new ResponseEntity<String>(ApplicationConstants.NOT_FOUND, HttpStatus.NOT_FOUND);
    }
    final String reviewFindUrl = ApplicationConstants.REVIEW_FINDBY_MOVIE_URL
        + movieAccountObj.get().getId();
    ResponseEntity<ReviewDto> reviewDto = restTemplate.getForEntity(reviewFindUrl, ReviewDto.class);
    ModelMapper modelMapper = new ModelMapper();
    MovieDto movieDto = modelMapper.map(movieAccountObj.get(), MovieDto.class);
    movieDto.setRate(reviewDto.getBody().getRating());
    movieDto.setComment(reviewDto.getBody().getComment());
    return new ResponseEntity<MovieDto>(movieDto, HttpStatus.OK);
  }

  /**
   * Gets the all movies.
   *
   * @return the all movies
   */
  @GetMapping(value = "/getAll")
  public ResponseEntity<?> getAllMovies() {
    List<Movie> movieList = movieRepository.findAll();
    return new ResponseEntity<List<Movie>>(movieList, HttpStatus.OK);
  }

  /**
   * Movie paging.
   *
   * @param pageNo
   *          the page no
   * @return the response entity
   */
  @GetMapping(value = "/paging")
  public ResponseEntity<?> moviePaging(@RequestParam int pageNo) {
    Pageable pageable = createPageRequest(pageNo);
    Page<Movie> page = movieRepository.findAll(pageable);
    ModelMapper modelMapper = new ModelMapper();
    PageDtoResponse pageDtoResponse = modelMapper.map(page, PageDtoResponse.class);
    return new ResponseEntity<PageDtoResponse>(pageDtoResponse, HttpStatus.OK);
  }

  /**
   * Creates the page request.
   *
   * @param pageNo
   *          the page no
   * @return the pageable
   */
  private Pageable createPageRequest(int pageNo) {
    return PageRequest.of(pageNo, pageMaxLimit);
  }

}
