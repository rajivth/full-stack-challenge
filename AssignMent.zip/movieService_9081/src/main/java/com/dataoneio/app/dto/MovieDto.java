package com.dataoneio.app.dto;

import com.dataoneio.app.model.Actor;
import com.dataoneio.app.model.Director;
import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


/**
 * The Class MovieDto.
 */
public class MovieDto {

  /** The id. */
  private Long id;

  /** The name. */
  @NotNull
  @NotEmpty
  private String name;

  /** The img url. */
  private String imgUrl;

  /** The release date. */
  @NotNull
  private Date releaseDate;

  /** The genre. */
  private String genre;

  /** The list actors. */
  @NotNull
  private List<Actor> listActors;

  /** The list directors. */
  @NotNull
  private Director director;
  
  /** The rate. */
  private String rate;
  
  /** The comment. */
  private String comment;

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "MovieDto [id=" + id + ", name=" + name + ", imgUrl=" + imgUrl + ", releaseDate="
        + releaseDate + ", genre=" + genre + ", listActors=" + listActors + ", director=" + director
        + ", rate=" + rate + ", comment=" + comment + "]";
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public Long getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id
   *          the new id
   */
  public void setId(Long id) {
    this.id = id;
  }

  /**
   * Gets the name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Sets the name.
   *
   * @param name
   *          the new name
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Gets the img url.
   *
   * @return the img url
   */
  public String getImgUrl() {
    return imgUrl;
  }

  /**
   * Sets the img url.
   *
   * @param imgUrl
   *          the new img url
   */
  public void setImgUrl(String imgUrl) {
    this.imgUrl = imgUrl;
  }

  /**
   * Gets the release date.
   *
   * @return the release date
   */
  public Date getReleaseDate() {
    return releaseDate;
  }

  /**
   * Sets the release date.
   *
   * @param releaseDate
   *          the new release date
   */
  public void setReleaseDate(Date releaseDate) {
    this.releaseDate = releaseDate;
  }

  /**
   * Gets the genre.
   *
   * @return the genre
   */
  public String getGenre() {
    return genre;
  }

  /**
   * Sets the genre.
   *
   * @param genre
   *          the new genre
   */
  public void setGenre(String genre) {
    this.genre = genre;
  }

  /**
   * Gets the list actors.
   *
   * @return the list actors
   */
  public List<Actor> getListActors() {
    return listActors;
  }

  /**
   * Sets the list actors.
   *
   * @param listActors
   *          the new list actors
   */
  public void setListActors(List<Actor> listActors) {
    this.listActors = listActors;
  }

  /**
   * Gets the director.
   *
   * @return the director
   */
  public Director getDirector() {
    return director;
  }

  /**
   * Sets the director.
   *
   * @param director
   *          the new director
   */
  public void setDirector(Director director) {
    this.director = director;
  }

  /**
   * Gets the rate.
   *
   * @return the rate
   */
  public String getRate() {
    return rate;
  }

  /**
   * Sets the rate.
   *
   * @param rate the new rate
   */
  public void setRate(String rate) {
    this.rate = rate;
  }

  /**
   * Gets the comment.
   *
   * @return the comment
   */
  public String getComment() {
    return comment;
  }

  /**
   * Sets the comment.
   *
   * @param comment the new comment
   */
  public void setComment(String comment) {
    this.comment = comment;
  }
  
  
}
