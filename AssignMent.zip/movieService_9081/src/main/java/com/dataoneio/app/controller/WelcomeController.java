package com.dataoneio.app.controller;

import com.dataoneio.app.util.ApplicationConstants;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * The Class WelcomeController.
 */
@RestController
public class WelcomeController {

  /**
   * Home.
   *
   * @return the string
   */
  @RequestMapping(method = RequestMethod.GET, value = "/")
  public String home() {
    return ApplicationConstants.START_UP_MSG;
  }
}