insert into actor
values(1001,'actor1');

insert into actor
values(1002,'actor2');

insert into actor
values(1003,'actor3');

insert into actor
values(1004,'actor4');



insert into director
values(2001,'director1');

insert into director
values(2002,'director2');

insert into director
values(2003,'director3');

insert into director
values(2004,'director4');




insert into movie (id, genre, img_url, name, release_date, director_id) values (1001, 'HOROR1', 'http://localhost:9081/h2','HOROR1', sysdate, 2001);
insert into movie (id, genre, img_url, name, release_date, director_id) values (1002, 'HOROR1', 'http://localhost:9081/h2','HOROR1', sysdate, 2001);
insert into movie (id, genre, img_url, name, release_date, director_id) values (1003, 'HOROR1', 'http://localhost:9081/h2','HOROR1', sysdate, 2001);
insert into movie (id, genre, img_url, name, release_date, director_id) values (1004, 'HOROR1', 'http://localhost:9081/h2','HOROR1', sysdate, 2001);
insert into movie (id, genre, img_url, name, release_date, director_id) values (1005, 'HOROR1', 'http://localhost:9081/h2','HOROR1', sysdate, 2001);
insert into movie (id, genre, img_url, name, release_date, director_id) values (1006, 'HOROR1', 'http://localhost:9081/h2','HOROR1', sysdate, 2001);
insert into movie (id, genre, img_url, name, release_date, director_id) values (1007, 'HOROR1', 'http://localhost:9081/h2','HOROR1', sysdate, 2001);
insert into movie (id, genre, img_url, name, release_date, director_id) values (1008, 'HOROR1', 'http://localhost:9081/h2','HOROR1', sysdate, 2001);
insert into movie (id, genre, img_url, name, release_date, director_id) values (1009, 'HOROR1', 'http://localhost:9081/h2','HOROR1', sysdate, 2001);
insert into movie (id, genre, img_url, name, release_date, director_id) values (1010, 'HOROR1', 'http://localhost:9081/h2','HOROR1', sysdate, 2001);
insert into movie (id, genre, img_url, name, release_date, director_id) values (1011, 'HOROR1', 'http://localhost:9081/h2','HOROR1', sysdate, 2001);
insert into movie (id, genre, img_url, name, release_date, director_id) values (1012, 'HOROR1', 'http://localhost:9081/h2','HOROR1', sysdate, 2001);


insert into movie_actor (movie_id, actor_id) values (1001, 1001);
insert into movie_actor (movie_id, actor_id) values (1002, 1001);
insert into movie_actor (movie_id, actor_id) values (1003, 1001);
insert into movie_actor (movie_id, actor_id) values (1004, 1001);
insert into movie_actor (movie_id, actor_id) values (1005, 1001);
insert into movie_actor (movie_id, actor_id) values (1006, 1001);
insert into movie_actor (movie_id, actor_id) values (1007, 1001);
insert into movie_actor (movie_id, actor_id) values (1008, 1001);
insert into movie_actor (movie_id, actor_id) values (1009, 1001);
insert into movie_actor (movie_id, actor_id) values (1010, 1001);
insert into movie_actor (movie_id, actor_id) values (1011, 1001);
insert into movie_actor (movie_id, actor_id) values (1012, 1001);