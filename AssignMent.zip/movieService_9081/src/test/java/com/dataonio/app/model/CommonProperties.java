package com.dataonio.app.model;

import static org.junit.Assert.assertNotNull;

import com.dataoneio.app.dto.MovieDto;
import com.dataoneio.app.dto.PageDtoResponse;
import com.dataoneio.app.dto.ReviewDto;
import com.dataoneio.app.dto.UserDto;
import com.dataoneio.app.model.Actor;
import com.dataoneio.app.model.Director;
import com.dataoneio.app.model.Movie;
import org.agileware.test.PropertiesTester;
import org.junit.Test;
import org.mockito.Mockito;


/**
 * The Class CommonProperties.
 */
public class CommonProperties {

  /**
   * Test properties.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testProperties() throws Exception {

    PropertiesTester tester = new PropertiesTester();
    tester.testAll(Actor.class);

    tester = new PropertiesTester();
    tester.testAll(Director.class);

    tester = new PropertiesTester();
    tester.testAll(Movie.class);
    
    tester = new PropertiesTester();
    tester.testAll(MovieDto.class);
    
    tester = new PropertiesTester();
    tester.testAll(UserDto.class);
    
    tester = new PropertiesTester();
    tester.testAll(PageDtoResponse.class);
    
    tester = new PropertiesTester();
    tester.testAll(ReviewDto.class);
    
    assertNotNull(Actor.class.newInstance().toString());
    assertNotNull(Director.class.newInstance().toString());
    assertNotNull(Movie.class.newInstance().toString());
    assertNotNull(MovieDto.class.newInstance().toString());
    assertNotNull(UserDto.class.newInstance().toString());
    assertNotNull(PageDtoResponse.class.newInstance().toString());
    assertNotNull(ReviewDto.class.newInstance().toString());

    ReviewDto reviewDto =  new ReviewDto(0L, "rating", "comment", 0L);
    Mockito.spy(reviewDto);
   }
  
}
