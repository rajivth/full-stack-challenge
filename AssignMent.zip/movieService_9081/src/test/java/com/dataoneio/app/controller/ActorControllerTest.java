package com.dataoneio.app.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.dataoneio.app.model.Actor;
import com.dataoneio.app.repository.ActorRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;



// TODO: Auto-generated Javadoc
/**
 * The Class WelcomeControllerTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class ActorControllerTest {

  /** The mock mvc. */
  private MockMvc mockMvc;

  /** The actor controller. */
  @InjectMocks
  private ActorController actorController;

  /** The actor repository. */
  @Mock
  private ActorRepository actorRepository;

  /** The model mapper. */
  @Mock
  private ModelMapper modelMapper;

  /** The actor json. */
  private String actorJson;

  /** The id. */
  private Long id = -1L;

  /** The object mapper. */
  private ObjectMapper objectMapper;

  /**
   * Inits the.
   */
  @Before
  public void init() {
    MockitoAnnotations.initMocks(this);
    mockMvc = MockMvcBuilders.standaloneSetup(actorController).build();
    actorJson = "{" + "  \"id\": 0," + "  \"name\": \"ActorTest\"" + "}";
    objectMapper = new ObjectMapper();
  }

  /**
   * Creates the actor test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void createActorTest() throws Exception {

    Actor actorObj = objectMapper.readValue(actorJson, Actor.class);
    Mockito.when(actorRepository.save(actorObj)).thenReturn(actorObj);

    final String post_Url = com.dataoneio.app.util.ApplicationConstants.ACTOR_API_URL + "/add";
    MvcResult result = mockMvc
        .perform(post(post_Url).contentType(MediaType.APPLICATION_JSON).content(actorJson))
        .andExpect(status().isOk()).andReturn();

    org.junit.Assert.assertEquals(result.getResponse().getContentAsString(),
        com.dataoneio.app.util.ApplicationConstants.SUCCESS_MSG);
  }

  /**
   * Update actor not found test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void updateActorNotFoundTest() throws Exception {
    Optional<Actor> actorAccountOptional = Optional.empty();
    Mockito.when(actorRepository.findById(id)).thenReturn(actorAccountOptional);
    final String update_Url = com.dataoneio.app.util.ApplicationConstants.ACTOR_API_URL
        + "/update/{id}";
    MvcResult result = mockMvc
        .perform(put(update_Url, id).contentType(MediaType.APPLICATION_JSON).content(actorJson))
        .andExpect(status().isNotFound()).andReturn();
    org.junit.Assert.assertEquals(result.getResponse().getContentAsString(),
        com.dataoneio.app.util.ApplicationConstants.UPDATE_ERROR_MSG);
  }

  /**
   * User found test.
   *
   * @throws Exception
   *           the exception
   */

  @Test
  public void userFoundTest() throws Exception {
    id = 0L;
    Actor actor = objectMapper.readValue(actorJson, Actor.class);
    Optional<Actor> userOptional = Optional.of(actor);
    Mockito.when(actorRepository.findById(id)).thenReturn(userOptional);
    final String update_Url = com.dataoneio.app.util.ApplicationConstants.ACTOR_API_URL
        + "/update/{id}";
    MvcResult result = mockMvc
        .perform(put(update_Url, id).contentType(MediaType.APPLICATION_JSON).content(actorJson))
        .andExpect(status().isOk()).andReturn();
    Actor actorFoundObj = objectMapper.readValue(result.getResponse().getContentAsString(),
        new TypeReference<Actor>() {
        });
    org.junit.Assert.assertEquals(actorFoundObj.getId(), id);
  }

  /**
   * Find actors.
   *
   * @throws Exception the exception
   */
  @Test
  public void findActorsTest() throws Exception {
    Mockito.when(actorRepository.findAll()).thenReturn(new ArrayList<Actor>());
    final String findAllActors_Url = com.dataoneio.app.util.ApplicationConstants.ACTOR_API_URL
        + "/findAll";
    mockMvc.perform(get(findAllActors_Url)).andExpect(status().isOk()).andReturn();
  }
  
}