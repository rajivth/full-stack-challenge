package com.dataoneio.app.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.dataoneio.app.dto.MovieDto;
import com.dataoneio.app.dto.ReviewDto;
import com.dataoneio.app.model.Movie;
import com.dataoneio.app.repository.MovieRepository;
import com.dataoneio.app.util.ApplicationConstants;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BindingResult;
import org.springframework.web.client.RestTemplate;


/**
 * The Class WelcomeControllerTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootConfiguration
public class MovieControllerTest {

  /** The mock mvc. */
  private MockMvc mockMvc;

  /** The actor controller. */
  @InjectMocks
  private MovieController movieController;

  /** The movie repository. */
  @Mock
  private MovieRepository movieRepository;

  /** The movie json. */
  private String movieJson;

  /** The Constant ID. */
  private static final Long ID = 0L;

  /** The object mapper. */
  private ObjectMapper objectMapper;

  /** The rest template. */
  @Mock
  private RestTemplate restTemplate;

  /** The movie. */
  @Mock
  private Movie movieObject;

  /** The movie dto. */
  @Mock
  private MovieDto movieDto;
  /** The review dto. */
  @Mock
  private ReviewDto reviewDto;

  /** The result. */
  @Mock
  private BindingResult result;

  /**
   * Inits the.
   */
  @Before
  public void init() {
    mockMvc = MockMvcBuilders.standaloneSetup(movieController).build();

    movieJson = "{" + "  \"director\": {" + "    \"id\": 1001," + "  "
        + "    \"name\": \"director1\"" + "  }," + "  \"genre\": \"HOROR\"," + "  \"id\": 0,"
        + "  \"imgUrl\": \"http://localhost:9081/swagger-ui.html\"," + "  \"listActors\": ["
        + "    {" + "      \"id\": 1001," + "      \"name\": \"actor1\"" + "    }" + "  ],"
        + "  \"name\": \"HORROR1\"," + "  \"releaseDate\": \"2018-12-22T07:26:22.113Z\"" + "}";

    objectMapper = new ObjectMapper();
    reviewDto = new ReviewDto();
    reviewDto.setId(ID);
  }

  /**
   * Home test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void fieldEmptyMovieTest() throws Exception {

    Optional<Movie> movieOptional = Optional.empty();
    final String movie_Url = ApplicationConstants.MOVIE_API_URL + "/add";
    mockMvc.perform(post(movie_Url).content(objectMapper.writeValueAsString(movieOptional))
        .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();
  }

  /**
   * Home test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void createMovieTest() throws Exception {
    movieController.createMovie(objectMapper.readValue(movieJson, MovieDto.class), result);
  }

  /**
   * Update movie test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void updateMovieTest() throws Exception {
    Movie movie = objectMapper.readValue(movieJson, Movie.class);
    Optional<Movie> movieOptional = Optional.of(movie);
    Mockito.when(movieRepository.findById(ID)).thenReturn(movieOptional);
    movieController.updateMovie(objectMapper.readValue(movieJson, MovieDto.class), ID);
  }

  /**
   * Update movie test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void updateMovieNotFoundTest() throws Exception {
    Optional<Movie> movieOptional = Optional.empty();
    Mockito.when(movieRepository.findById(ID)).thenReturn(movieOptional);
    movieController.updateMovie(objectMapper.readValue(movieJson, MovieDto.class), ID);
  }

  /**
   * Delete movie test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void deleteMovieTest() throws Exception {
    Movie movie = objectMapper.readValue(movieJson, Movie.class);
    Optional<Movie> movieOptional = Optional.of(movie);
    Mockito.when(movieRepository.findById(ID)).thenReturn(movieOptional);
    movieController.deleteMovie(ID);
  }

  /**
   * Delete movie test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void deleteMovieNotFoundTest() throws Exception {
    Optional<Movie> movieOptional = Optional.empty();
    Mockito.when(movieRepository.findById(ID)).thenReturn(movieOptional);
    movieController.deleteMovie(ID);
  }

  /**
   * Gets the movie not found test.
   * 
   * @throws Exception
   *           the exception
   */
  @Test
  public void getMovieNotFoundTest() throws Exception {
    Optional<Movie> movieOptional = Optional.empty();
    Mockito.when(movieRepository.findById(ID)).thenReturn(movieOptional);
    movieController.getMovie(ID);
  }

  /**
   * Gets the movie found test.
   * 
   * @throws Exception
   *           the exception
   */
  @Test
  public void getMovieFoundTest() throws Exception {
    Movie movie = objectMapper.readValue(movieJson, Movie.class);
    Optional<Movie> movieOptional = Optional.of(movie);
    Mockito.when(movieRepository.findById(ID)).thenReturn(movieOptional);
    final String reviewFindUrl = ApplicationConstants.REVIEW_FINDBY_MOVIE_URL + ID;
    ResponseEntity<ReviewDto> responseEntity = new ResponseEntity<>(reviewDto, HttpStatus.OK);
    Mockito.when(restTemplate.getForEntity(reviewFindUrl, ReviewDto.class))
        .thenReturn(responseEntity);
    movieController.getMovie(ID);
  }

  /**
   * Gets the all movies.
   */
  @Test
  public void getAllMovies() {
    Mockito.when(movieRepository.findAll()).thenReturn(new ArrayList<Movie>());
    movieController.getAllMovies();
  }
  
}