package com.dataoneio.app.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.dataoneio.app.model.Director;
import com.dataoneio.app.repository.DirectorRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;


/**
 * The Class WelcomeControllerTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class DirectorControllerTest {

  /** The mock mvc. */
  private MockMvc mockMvc;

  /** The director controller. */
  @InjectMocks
  private DirectorController directorController;

  /** The director repository. */
  @Mock
  private DirectorRepository directorRepository;

  /** The model mapper. */
  @Mock
  private ModelMapper modelMapper;

  /** The director json. */
  private String directorJson;

  /** The id. */
  private Long id = -1L;

  /** The object mapper. */
  private ObjectMapper objectMapper;

  /**
   * Inits the.
   */
  @Before
  public void init() {
    MockitoAnnotations.initMocks(this);
    mockMvc = MockMvcBuilders.standaloneSetup(directorController).build();
    directorJson = "{" + "  \"id\": 0," + "  \"name\": \"DirectorTest\"" + "}";
    objectMapper = new ObjectMapper();
  }

  /**
   * Creates the director test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void createDirectorTest() throws Exception {

    Director directorObj = objectMapper.readValue(directorJson, Director.class);
    Mockito.when(directorRepository.save(directorObj)).thenReturn(directorObj);

    final String post_Url = com.dataoneio.app.util.ApplicationConstants.DIRECTOR_API_URL + "/add";
    MvcResult result = mockMvc
        .perform(post(post_Url).contentType(MediaType.APPLICATION_JSON).content(directorJson))
        .andExpect(status().isOk()).andReturn();

    org.junit.Assert.assertEquals(result.getResponse().getContentAsString(),
        com.dataoneio.app.util.ApplicationConstants.SUCCESS_MSG);
  }

  /**
   * Update director not found test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void updateDirectorNotFoundTest() throws Exception {
    Optional<Director> directorAccountOptional = Optional.empty();
    Mockito.when(directorRepository.findById(id)).thenReturn(directorAccountOptional);
    final String update_Url = com.dataoneio.app.util.ApplicationConstants.DIRECTOR_API_URL
        + "/update/{id}";
    MvcResult result = mockMvc
        .perform(put(update_Url, id).contentType(MediaType.APPLICATION_JSON).content(directorJson))
        .andExpect(status().isNotFound()).andReturn();
    org.junit.Assert.assertEquals(result.getResponse().getContentAsString(),
        com.dataoneio.app.util.ApplicationConstants.UPDATE_ERROR_MSG);
  }

  /**
   * Director found test.
   *
   * @throws Exception
   *           the exception
   */

  @Test
  public void directorFoundTest() throws Exception {
    id = 0L;
    Director director = objectMapper.readValue(directorJson, Director.class);
    Optional<Director> directorOptional = Optional.of(director);
    Mockito.when(directorRepository.findById(id)).thenReturn(directorOptional);
    final String update_Url = com.dataoneio.app.util.ApplicationConstants.DIRECTOR_API_URL
        + "/update/{id}";
    MvcResult result = mockMvc
        .perform(put(update_Url, id).contentType(MediaType.APPLICATION_JSON).content(directorJson))
        .andExpect(status().isOk()).andReturn();
    Director directorFoundObj = objectMapper.readValue(result.getResponse().getContentAsString(),
        new TypeReference<Director>() {
        });
    org.junit.Assert.assertEquals(directorFoundObj.getId(), id);
  }

  /**
   * Find actors.
   *
   * @throws Exception the exception
   */
  @Test
  public void findDirectorsTest() throws Exception {
    Mockito.when(directorRepository.findAll()).thenReturn(new ArrayList<Director>());
    final String findAllDirectors_Url = com.dataoneio.app.util.ApplicationConstants.DIRECTOR_API_URL
        + "/findAll";
    MvcResult result = mockMvc.perform(get(findAllDirectors_Url)).andExpect(status().isOk())
        .andReturn();
  
  }
}