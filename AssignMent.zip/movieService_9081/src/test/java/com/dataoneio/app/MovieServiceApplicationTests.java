package com.dataoneio.app;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * The Class MovieServiceApplicationTests.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class MovieServiceApplicationTests {

  /**
   * Context loads.
   */
  @Test
  public void contextLoads() {
    MovieServiceApplication.main(new String[] {});
  }

}
