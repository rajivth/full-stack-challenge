var app = angular.module('angularTable', ['angularUtils.directives.dirPagination']);

app.controller('listdata',function($scope, $http ,$log){
	
	//$scope.workFlow="ADD";
	$scope.movies = []; //declare an empty array
	$scope.listActor = [];
	$scope.listDirector = [];
	$scope.listRatings = ["Rating1","Rating2","Rating3","Rating4","Rating5"];
	
	$scope.classDisabled="disabled";
	$scope.activeNode="active";
	$scope.totalPages=0;
	
$scope.movie = {
  "director": {
    "id": 0,
    "name": ""
  },
  "genre": "",
  "id": 0,
  "imgUrl": "",
  "listActors": [
    {
      "id": 0,
      "name": ""
    }
  ],
  "name": "",
  "releaseDate": "",
  "rate":"",
  "comment":""
}

	
	$scope.pagination = function(){
	$http.get("http://localhost:9081/api/movie/getAll").success(function(response){ 

		$scope.movies = response; 
		$scope.getListActors();
		$scope.getListDirectors();
		});
	}
	$scope.pagination();
	
	$scope.sort = function(keyname){
		$scope.sortKey = keyname;   //set the sortKey to the param passed
		$scope.reverse = !$scope.reverse; //if true make it false and vice versa
	}
	
	$scope.getListActors = function() {
		$http.get("http://localhost:9081/api/actor/findAll").success(function(response){ 
		$scope.listActors = response;  //ajax request to fetch data into $scope.data
					});	
			};
	$scope.getListDirectors = function() {
		$http.get("http://localhost:9081/api/director/findAll").success(function(response){ 
		$scope.listDirector = response;  //ajax request to fetch data into $scope.data	
			});	
		};
	$scope.pageChanged = function() {
						$log.log('Page Changed to: ' + $scope.currentPage);
		};
		
		$scope.movieSubmit = function() {
						
						//$log.log(+":Before:+"+JSON.stringify($scope.movie));
						if($scope.movie.director.id=="0"){
							$scope.movie.director=null;
						}

						if($scope.movie.listActors[0].id=="0"){
						
							$scope.movie.listActors=null;
						}
						
						$log.log("After \n+"+JSON.stringify( $scope.movie));
				$http({
                        url: "http://localhost:9081/api/movie/add",
                        method: "POST",
                        data: $scope.movie
                    }).success(function(data, status, headers, config) {
                        $scope.status = status;
						document.getElementById('alert-info').innerHTML=data;
						$scope.movie = new Object();
						$scope.pagination();
						$log.log("Response \n+"+JSON.stringify(data));
                    }).error(function(data, status, headers, config) {
                        $scope.status = status;
                    });
            };
		
		$scope.deleteMovie = function(id) {
		$log.log("Response \n+"+id);
			$http({
                        url: "http://localhost:9081/api/movie/delete/"+id,
                        method: "delete",
                        }).success(function(data, status, headers, config) {
                        $scope.status = status;
						$scope.pagination();
						document.getElementById('alert-info').innerHTML=data;
						$log.log("Response \n+"+JSON.stringify(data));
                    }).error(function(data, status, headers, config) {
                        $scope.status = status;
                    });
		};
		
		
		$scope.findMovie = function(id) {
		$log.log("Response \n+"+id);
		//$scope.workFlow="UPDATE";
			$http({
                        url: "http://localhost:9081/api/movie/find/"+id,
                        method: "get",
                        }).success(function(data, status, headers, config) {
                        $scope.movie = data;
						$log.log("Response \n+"+JSON.stringify(data));
                    }).error(function(data, status, headers, config) {
                        $scope.status = status;
                    });
		};
		
		
		
		
});