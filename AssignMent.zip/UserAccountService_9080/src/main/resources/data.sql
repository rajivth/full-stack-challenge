


insert into user_account values ('admin@yahoo.com','admin', '2018-12-12','admin');
insert into user_account values ('admin1@yahoo.com','admin', '2018-12-12','admin');
insert into user_account values ('admin2@yahoo.com','admin', '2018-12-12','admin');
insert into user_account values ('admin3@yahoo.com','admin', '2018-12-12','admin');
insert into user_account values ('admin4@yahoo.com','admin', '2018-12-12','admin');
