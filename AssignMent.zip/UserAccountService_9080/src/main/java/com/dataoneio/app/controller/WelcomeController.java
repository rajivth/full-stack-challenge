package com.dataoneio.app.controller;

import com.dataoneio.app.utils.ApplicationConstants;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * The Class WelcomeController.
 */
@RestController
public class WelcomeController {

  /**
   * Home.
   *
   * @return the string
   */
  @GetMapping("/")
  public String home() {
    return ApplicationConstants.SERVICE_UP_MESSAGE;
  }
}