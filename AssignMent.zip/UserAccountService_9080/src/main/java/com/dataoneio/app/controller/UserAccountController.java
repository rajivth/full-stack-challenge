package com.dataoneio.app.controller;

import com.dataoneio.app.model.UserAccount;
import com.dataoneio.app.repository.UserAccountRepository;
import com.dataoneio.app.utils.ApplicationConstants;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * The Class UserAccountController.
 */
@RestController
@RequestMapping("/api/account")
public class UserAccountController {

  /** The user account repository. */
  @Autowired
  private UserAccountRepository userAccountRepository;

  /**
   * Users.
   *
   * @return the list
   */
  @GetMapping("users")
  public ResponseEntity<?> users() {
    List<UserAccount> listUsers = userAccountRepository.findAll();
    return new ResponseEntity<List<UserAccount>>(listUsers, HttpStatus.OK);
  }

  /**
   * Retrieve user.
   *
   * @param email
   *          the email
   * @return the user account
   */
  @GetMapping("users/{email}")
  public ResponseEntity<?> retrieveUser(@PathVariable final String email) {
    Optional<UserAccount> userAccountOptional = userAccountRepository.findById(email);
    if (!userAccountOptional.isPresent()) {
      return new ResponseEntity<String>(ApplicationConstants.USER_NOT_FOUND, HttpStatus.NOT_FOUND);
    } else {
      return new ResponseEntity<UserAccount>(userAccountOptional.get(), HttpStatus.OK);
    }
  }

  /**
   * Delete user.
   *
   * @param email
   *          the email
   * @return the response entity
   */
  @DeleteMapping("users/{email}")
  public ResponseEntity<?> deleteUser(@PathVariable final String email) {
    Optional<UserAccount> userAccountOptional = userAccountRepository.findById(email);
    if (!userAccountOptional.isPresent()) {
      return new ResponseEntity<String>(ApplicationConstants.USER_NOT_FOUND, HttpStatus.NOT_FOUND);
    } else {
      userAccountRepository.deleteById(email);
      return new ResponseEntity<String>(ApplicationConstants.USER_DELETE_MSG, HttpStatus.OK);
    }

  }

  /**
   * Update student.
   *
   * @param userRequest
   *          the user request
   * @param email
   *          the email
   * @return the response entity
   */
  @PutMapping("users/{email}")
  public ResponseEntity<?> updateStudent(@RequestBody final UserAccount userRequest,
      @PathVariable final String email) {

    Optional<UserAccount> userAccountOptional = userAccountRepository.findById(email);

    if (!userAccountOptional.isPresent()) {
      return new ResponseEntity<String>(ApplicationConstants.USER_NOT_FOUND, HttpStatus.NOT_FOUND);
    }

    userRequest.setEmailAddress(email);

    userAccountRepository.save(userRequest);

    return new ResponseEntity<UserAccount>(userRequest, HttpStatus.OK);
  }

}
