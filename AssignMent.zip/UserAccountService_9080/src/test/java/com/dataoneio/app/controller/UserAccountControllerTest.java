package com.dataoneio.app.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.dataoneio.app.model.UserAccount;
import com.dataoneio.app.repository.UserAccountRepository;
import com.dataoneio.app.utils.ApplicationConstants;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import java.util.List;
import java.util.Optional;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

/**
 * The Class UserAccountControllerTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class UserAccountControllerTest {

  /** The mock mvc. */
  private MockMvc mockMvc;

  /** The user account repository. */
  @Mock
  private UserAccountRepository userAccountRepository;

  /** The user account controller. */
  @InjectMocks
  private UserAccountController userAccountController;

  /** The user json. */
  private String userJson;

  /** The object mapper. */
  private ObjectMapper objectMapper;

  /** The users list. */
  private List<UserAccount> usersList = null;

  /** The not found email. */
  private static final String NOT_FOUND_EMAIL = "notfound@gmail.com";

  /** The email address exist. */
  private static final String EMAIL_ADDRESS_EXIST = "admin@yahoo";

  /**
   * Sets the up.
   *
   * @throws Exception
   *           the exception
   */
  @Before
  public void setUp() throws Exception {
    mockMvc = MockMvcBuilders.standaloneSetup(userAccountController).build();

    userJson = "[" + "  {" + "    \"firstName\": \"admin\"," + "    \"lastName\": \"admin\","
        + "    \"emailAddress\": \"admin@yahoo\","
        + "    \"joining\": \"2018-12-11T18:30:00.000+0000\"" + "  }," + "  {"
        + "    \"firstName\": \"admin\"," + "    \"lastName\": \"admin\","
        + "    \"emailAddress\": \"admin1@yahoo.com\","
        + "    \"joining\": \"2018-12-11T18:30:00.000+0000\"" + "  }," + "  {"
        + "    \"firstName\": \"admin\"," + "    \"lastName\": \"admin\","
        + "    \"emailAddress\": \"admin2@yahoo.com\","
        + "    \"joining\": \"2018-12-11T18:30:00.000+0000\"" + "  }," + "  {"
        + "    \"firstName\": \"admin\"," + "    \"lastName\": \"admin\","
        + "    \"emailAddress\": \"admin3@yahoo.com\","
        + "    \"joining\": \"2018-12-11T18:30:00.000+0000\"" + "  }," + "  {"
        + "    \"firstName\": \"admin\"," + "    \"lastName\": \"admin\","
        + "    \"emailAddress\": \"admin4@yahoo.com\","
        + "    \"joining\": \"2018-12-11T18:30:00.000+0000\"" + "  }" + "]";


    objectMapper = new ObjectMapper();
    usersList = objectMapper.readValue(userJson,
        TypeFactory.defaultInstance().constructCollectionType(List.class, UserAccount.class));
  }

  /**
   * Users test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void usersTest() throws Exception {
    Mockito.when(userAccountRepository.findAll()).thenReturn(usersList);
    final String user_Url = ApplicationConstants.USER_ACCOUNT_URL + "users";
    MvcResult result = mockMvc.perform(get(user_Url)).andExpect(status().isOk()).andReturn();
    List<UserAccount> actual = objectMapper.readValue(result.getResponse().getContentAsString(),
        new TypeReference<List<UserAccount>>() {
        });
    org.junit.Assert.assertEquals(actual.size(), usersList.size());
  }

  /**
   * Retrieve user not found test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void retrieveUserNotFoundTest() throws Exception {
    Mockito.when(userAccountRepository.findById(NOT_FOUND_EMAIL)).thenReturn(null);
    final String reterive_Url = ApplicationConstants.USER_ACCOUNT_URL + "users/" + NOT_FOUND_EMAIL;
    MvcResult result = mockMvc.perform(get(reterive_Url)).andExpect(status().isNotFound())
        .andReturn();
    org.junit.Assert.assertEquals(result.getResponse().getContentAsString(),
        ApplicationConstants.USER_NOT_FOUND);
  }

  /**
   * User found test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void userFoundTest() throws Exception {

    ObjectMapper objectMapper = new ObjectMapper();
    Optional<UserAccount> userOptional = Optional.of(usersList.get(0));
    Mockito.when(userAccountRepository.findById(EMAIL_ADDRESS_EXIST)).thenReturn(userOptional);
    final String reterive_Url = ApplicationConstants.USER_ACCOUNT_URL + "users/"
        + EMAIL_ADDRESS_EXIST;
    MvcResult result = mockMvc.perform(get(reterive_Url)).andExpect(status().isOk()).andReturn();
    UserAccount userFoundObj = objectMapper.readValue(result.getResponse().getContentAsString(),
        new TypeReference<UserAccount>() {
        });
    org.junit.Assert.assertEquals(usersList.get(0).getEmailAddress(),
        userFoundObj.getEmailAddress());
  }

  /**
   * Update student test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void updateStudentTest() throws Exception {

    Optional<UserAccount> userOptional = Optional.of(usersList.get(0));
    Mockito.when(userAccountRepository.findById(EMAIL_ADDRESS_EXIST)).thenReturn(userOptional);
    final String update_Url = ApplicationConstants.USER_ACCOUNT_URL + "users/{email}";
    MvcResult result = mockMvc
        .perform(put(update_Url, EMAIL_ADDRESS_EXIST).contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(usersList.get(0))))
        .andExpect(status().isOk()).andReturn();
    UserAccount userFoundObj = objectMapper.readValue(result.getResponse().getContentAsString(),
        new TypeReference<UserAccount>() {
        });
    org.junit.Assert.assertEquals(usersList.get(0).getEmailAddress(),
        userFoundObj.getEmailAddress());

  }

  @Test
  public void updateStudentNotFoundTest() throws Exception {

    Optional<UserAccount> userOptional = Optional.of(usersList.get(0));
    Mockito.when(userAccountRepository.findById(NOT_FOUND_EMAIL)).thenReturn(userOptional);
    final String update_Url = ApplicationConstants.USER_ACCOUNT_URL + "users/{email}";
    MvcResult result = mockMvc
        .perform(put(update_Url, EMAIL_ADDRESS_EXIST).contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(usersList.get(0))))
        .andExpect(status().isNotFound()).andReturn();
    org.junit.Assert.assertEquals(result.getResponse().getContentAsString(),
        ApplicationConstants.USER_NOT_FOUND);

  }

  @Test
  public void deleteUserNotFoundTest() throws Exception {
    Mockito.when(userAccountRepository.findById(NOT_FOUND_EMAIL)).thenReturn(null);
    final String delete_Url = ApplicationConstants.USER_ACCOUNT_URL + "users/" + NOT_FOUND_EMAIL;
    MvcResult result = mockMvc.perform(delete(delete_Url)).andExpect(status().isNotFound())
        .andReturn();
    org.junit.Assert.assertEquals(result.getResponse().getContentAsString(),
        ApplicationConstants.USER_NOT_FOUND);
  }

  @Test
  public void deleteFoundTest() throws Exception {

    Optional<UserAccount> userOptional = Optional.of(usersList.get(0));
    Mockito.when(userAccountRepository.findById(EMAIL_ADDRESS_EXIST)).thenReturn(userOptional);
    final String delete_Url = ApplicationConstants.USER_ACCOUNT_URL + "users/"
        + EMAIL_ADDRESS_EXIST;

    MvcResult result = mockMvc.perform(delete(delete_Url, EMAIL_ADDRESS_EXIST)).andReturn();
    org.junit.Assert.assertEquals(result.getResponse().getContentAsString(),
        ApplicationConstants.USER_DELETE_MSG);
  }

}
