package com.dataoneio.app;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * The Class UserAccountServiceApplicationTests.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class UserAccountServiceApplicationTests {

  /**
   * Context loads.
   */
  @Test
  public void contextLoads() {
    UserAccountServiceApplication.main(new String[] {});
  }

}
