package com.dataonio.app.model;

import static org.junit.Assert.assertNotNull;

import com.dataoneio.app.model.Review;
import org.agileware.test.PropertiesTester;
import org.junit.Test;



/**
 * The Class CommonProperties.
 */
public class CommonProperties {

  /**
   * Test properties.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testProperties() throws Exception {

    PropertiesTester tester = new PropertiesTester();
    tester.testAll(Review.class);
    assertNotNull(Review.class.newInstance().toString());
    
    assertNotNull(Review.class.newInstance().toString());
  }
}
