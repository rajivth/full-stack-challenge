package com.dataoneio.app.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.dataoneio.app.model.Review;
import com.dataoneio.app.repository.ReviewRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;



/**
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class ReviewControllerTest {

  /** The mock mvc. */
  private MockMvc mockMvc;

  /** The actor controller. */
  @InjectMocks
  private ReviewController reviewController;

  /** The actor repository. */
  @Mock
  private ReviewRepository reviewRepository;

  /** The model mapper. */
  @Mock
  private ModelMapper modelMapper;

  /** The actor json. */
  private String reviewJson;

  /** The id. */
  private Long id = -1L;

  /** The object mapper. */
  private ObjectMapper objectMapper;

  /**
   * Inits the.
   */
  @Before
  public void init() {
    MockitoAnnotations.initMocks(this);
    mockMvc = MockMvcBuilders.standaloneSetup(reviewController).build();
    reviewJson = "{" + "  \"comment\": \"string\"," + "  \"id\": 0," + "  \"movieId\": 1,"
        + "  \"rating\": \"string\"" + "}";
    ;
    objectMapper = new ObjectMapper();
  }

  /**
   * Creates the actor test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void createReviewTest() throws Exception {

    Review reviewObj = objectMapper.readValue(reviewJson, Review.class);
    Mockito.when(reviewRepository.save(reviewObj)).thenReturn(reviewObj);

    final String post_Url = com.dataoneio.app.util.ApplicationConstants.REVIEW_API_URL + "/add";
    MvcResult result = mockMvc
        .perform(post(post_Url).contentType(MediaType.APPLICATION_JSON).content(reviewJson))
        .andExpect(status().isOk()).andReturn();

    org.junit.Assert.assertEquals(result.getResponse().getContentAsString(),
        com.dataoneio.app.util.ApplicationConstants.SUCCESS_MSG);
  }

  /**
   * Update actor not found test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void updateReviewNotFoundTest() throws Exception {
    Optional<Review> reviewOptional = Optional.empty();
    Mockito.when(reviewRepository.findById(id)).thenReturn(reviewOptional);
    final String update_Url = com.dataoneio.app.util.ApplicationConstants.REVIEW_API_URL
        + "/update/{id}";
    MvcResult result = mockMvc
        .perform(put(update_Url, -1L).contentType(MediaType.APPLICATION_JSON).content(reviewJson))
        .andExpect(status().isNotFound()).andReturn();
    org.junit.Assert.assertEquals(result.getResponse().getContentAsString(),
        com.dataoneio.app.util.ApplicationConstants.UPDATE_ERROR_MSG);
  }

  /**
   * User found test.
   *
   * @throws Exception
   *           the exception
   */

  @Test
  public void updateReviewFoundTest() throws Exception {
    id = 0L;
    Review reviewObj = objectMapper.readValue(reviewJson, Review.class);
    Optional<Review> reviewOptional = Optional.of(reviewObj);
    Mockito.when(reviewRepository.findById(id)).thenReturn(reviewOptional);
    final String update_Url = com.dataoneio.app.util.ApplicationConstants.REVIEW_API_URL
        + "/update/{id}";
    MvcResult result = mockMvc
        .perform(put(update_Url, id).contentType(MediaType.APPLICATION_JSON).content(reviewJson))
        .andExpect(status().isOk()).andReturn();
    Review reviewObjectFound = objectMapper.readValue(result.getResponse().getContentAsString(),
        new TypeReference<Review>() {
        });
    org.junit.Assert.assertEquals(reviewObjectFound.getId(), id);
  }

  /**
   * Find review test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void findReviewNotFoundTest() throws Exception {

    Mockito.when(reviewRepository.findByMovieId(id)).thenReturn(null);
    final String find_Url = com.dataoneio.app.util.ApplicationConstants.REVIEW_API_URL
        + "/findByMovie/{id}";
    mockMvc.perform(get(find_Url, id).contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk()).andReturn();
  }

  /**
   * Find review test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void findReviewFoundTest() throws Exception {
    Review reviewObj = objectMapper.readValue(reviewJson, Review.class);
    Optional<Review> reviewOptional = Optional.of(reviewObj);
    Mockito.when(reviewRepository.findByMovieId(id)).thenReturn(reviewOptional.get());
    final String find_Url = com.dataoneio.app.util.ApplicationConstants.REVIEW_API_URL
        + "/findByMovie/{id}";
    mockMvc.perform(get(find_Url, id).contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk()).andReturn();
  }

  /**
   * Find review test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void deleteReviewNotFoundTest() throws Exception {

    Mockito.when(reviewRepository.findByMovieId(id)).thenReturn(null);
    final String delete_Url = com.dataoneio.app.util.ApplicationConstants.REVIEW_API_URL
        + "/delete/{id}";
    mockMvc.perform(delete(delete_Url, id).contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk()).andReturn();
  }

  /**
   * Find review test.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void deleteReviewFoundTest() throws Exception {
    Review reviewObj = objectMapper.readValue(reviewJson, Review.class);
    Optional<Review> reviewOptional = Optional.of(reviewObj);
    Mockito.when(reviewRepository.findByMovieId(id)).thenReturn(reviewOptional.get());
    final String delete_Url = com.dataoneio.app.util.ApplicationConstants.REVIEW_API_URL
        + "/delete/{id}";
    mockMvc.perform(delete(delete_Url, id).contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk()).andReturn();
  }

  /**
   * Find all review rest.
   *
   * @throws Exception the exception
   */
  @Test
  public void findAllReviewRest() throws Exception {
    Mockito.when(reviewRepository.findAll()).thenReturn(new ArrayList<Review>());
    final String findAll_Url = com.dataoneio.app.util.ApplicationConstants.REVIEW_API_URL
        + "/findAll";
    mockMvc.perform(get(findAll_Url).contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk()).andReturn();

  }
}