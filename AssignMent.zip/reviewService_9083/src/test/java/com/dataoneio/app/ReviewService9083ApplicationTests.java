package com.dataoneio.app;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * The Class ReviewService9083ApplicationTests.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class ReviewService9083ApplicationTests {

  /**
   * Context loads.
   */
  @Test
  public void contextLoads() {
    ReviewService9083Application.main(new String[]{});
  }

}
