package com.dataoneio.app.util;

/**
 * The interface ApplicationConstants.
 */

public interface ApplicationConstants {

  /** The Constant UPDATE_ERROR_MSG. */
  public static final String UPDATE_ERROR_MSG = "Update Record is not found in db";

  /** The Constant SUCCESS_MSG. */
  public static final String SUCCESS_MSG = "The Db was created successfully";

  /** The Constant DELETE_SUCCESS_MSG. */
  public static final String DELETE_SUCCESS_MSG = "The db was deleted successfully";

  /** The Constant FIELD_ERROR_MESSAGE. */
  public static final String FIELD_ERROR_MESSAGE = "Validation errors of field -> ";

  /** The Constant SUCCESS_MSG. */
  public static final String UPDATE_MSG = "Update db is successfully updated.";

  /** The Constant MOVIE_API_URL. */
  public static final String MOVIE_API_URL = "/api/movie";

  /** The Constant START_UP_MSG. */
  public static final String START_UP_MSG = "Movies service  is Up on 9081";

  /** The Constant HOME_URL. */
  public static final String HOME_URL = "/";

  /** The Constant DIRECTOR_API_URL. */
  public static final String REVIEW_API_URL = "/api/review";

  /** The Constant DELETE_NOT_FOUND. */
  public static final String DELETE_NOT_FOUND = "Delete Record is not found in db";

}
