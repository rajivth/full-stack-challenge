package com.dataoneio.app.controller;

import com.dataoneio.app.model.Review;
import com.dataoneio.app.repository.ReviewRepository;
import com.dataoneio.app.util.ApplicationConstants;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * The Class ActorController.
 */
@RestController
@RequestMapping("/api/review")
public class ReviewController {

  /** The reviewRepository repository. */
  @Autowired
  private ReviewRepository reviewRepository;

  /**
   * Creates the actor. the person dto
   *
   * @param review the review
   * @return the response entity
   * @throws InstantiationException           the instantiation exception
   * @throws IllegalAccessException           the illegal access exception
   */
  @PostMapping("/add")
  public ResponseEntity<?> createReview(@RequestBody final Review review)
      throws InstantiationException, IllegalAccessException {
    reviewRepository.save(review);
    return new ResponseEntity<String>(ApplicationConstants.SUCCESS_MSG, HttpStatus.OK);
  }

  /**
   * Update actor. the person dto
   *
   * @param review the review
   * @param id          the id
   * @return the response entity
   */
  @PutMapping("/update/{id}")
  public ResponseEntity<?> updateReview(@RequestBody final Review review,
      @PathVariable final Long id) {

    Optional<Review> reviewOptional = reviewRepository.findById(id);

    if (!reviewOptional.isPresent()) {
      return new ResponseEntity<String>(ApplicationConstants.UPDATE_ERROR_MSG,
          HttpStatus.NOT_FOUND);
    }
    review.setId(id);

    reviewRepository.save(review);

    return new ResponseEntity<Review>(review, HttpStatus.OK);

  }

  /**
   * Update actor. the person dto
   * 
   * @param id
   *          the id
   * @return the response entity
   */
  @GetMapping("/findByMovie/{id}")
  public ResponseEntity<?> findReview(@PathVariable final Long id) {

    Review reviewOptional = reviewRepository.findByMovieId(id);

    if (reviewOptional == null) {
      return new ResponseEntity<Review>(reviewOptional,
          HttpStatus.NO_CONTENT);
    }
    return new ResponseEntity<Review>(reviewOptional, HttpStatus.OK);

  }
  
  /**
   * Update actor. the person dto
   * 
   * @param id
   *          the id
   * @return the response entity
   */
  @DeleteMapping("/delete/{id}")
  public ResponseEntity<?> deleteReview(@PathVariable final Long id) {

    Review reviewOptional = reviewRepository.findByMovieId(id);

    if (reviewOptional == null) {
      return new ResponseEntity<String>(ApplicationConstants.DELETE_NOT_FOUND,
          HttpStatus.OK);
    }
    
    reviewRepository.delete(reviewOptional);
    return new ResponseEntity<String>(ApplicationConstants.DELETE_SUCCESS_MSG, HttpStatus.OK);

  }
  
  /**
   * Creates the review.
   *
   * @return the response entity
   * @throws InstantiationException the instantiation exception
   * @throws IllegalAccessException the illegal access exception
   */
  @GetMapping("/findAll")
  public ResponseEntity<?> findAllReview()
      throws InstantiationException, IllegalAccessException {
    List<Review> reviewList = reviewRepository.findAll();
    return new ResponseEntity<List<Review>>(reviewList, HttpStatus.OK);
  }

}
