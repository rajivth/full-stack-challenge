package com.dataoneio.app.repository;

import com.dataoneio.app.model.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * The Interface ActorRepository.
 */
@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {

  public Review findByMovieId(Long movieId);
}
