package com.dataoneio.app.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * The Class Actor.
 */
@Entity
public class Review {

  /** The id. */
  @Id
  @GeneratedValue
  private Long id;

  /** The name. */

  private String rating;

  /** The comment. */
  private String comment;

  /** The movie id. */
  private Long movieId;

  /**
   * Gets the id.
   *
   * @return the id
   */
  public Long getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id
   *          the new id
   */
  public void setId(Long id) {
    this.id = id;
  }

  /**
   * Gets the rating.
   *
   * @return the rating
   */
  public String getRating() {
    return rating;
  }

  /**
   * Sets the rating.
   *
   * @param rating
   *          the new rating
   */
  public void setRating(String rating) {
    this.rating = rating;
  }

  /**
   * Gets the comment.
   *
   * @return the comment
   */
  public String getComment() {
    return comment;
  }

  /**
   * Sets the comment.
   *
   * @param comment
   *          the new comment
   */
  public void setComment(String comment) {
    this.comment = comment;
  }

  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "Review [id=" + id + ", rating=" + rating + ", comment=" + comment + ", movie_id="
        + movieId + "]";
  }


  /**
   * Gets the movie id.
   *
   * @return the movie id
   */
  public Long getMovieId() {
    return movieId;
  }

  /**
   * Sets the movie id.
   *
   * @param movieId the new movie id
   */
  public void setMovieId(Long movieId) {
    this.movieId = movieId;
  }

}
