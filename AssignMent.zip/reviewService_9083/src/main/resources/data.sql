insert into review (id,comment, rating,movie_id) values (1001,'Hello','Rating1',1001);
insert into review (id,comment, rating,movie_id) values (1002,'Hello','Rating2',1002);

insert into review (id,comment, rating,movie_id) values (1003,'Hello','Rating1',1003);
insert into review (id,comment, rating,movie_id) values (1004,'Hello','Rating2',1004);

insert into review (id,comment, rating,movie_id) values (1005,'Hello','Rating1',1005);
insert into review (id,comment, rating,movie_id) values (1006,'Hello','Rating2',1006);


insert into review (id,comment, rating,movie_id) values (1007,'Hello','Rating1',1007);
insert into review (id,comment, rating,movie_id) values (1008,'Hello','Rating2',1008);

insert into review (id,comment, rating,movie_id) values (1009,'Hello','Rating1',1009);
insert into review (id,comment, rating,movie_id) values (1010,'Hello','Rating2',1010);

insert into review (id,comment, rating,movie_id) values (1011,'Hello','Rating1',1011);
insert into review (id,comment, rating,movie_id) values (1012,'Hello','Rating2',1012);



