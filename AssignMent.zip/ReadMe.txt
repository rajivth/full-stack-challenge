Step-
1) First Run movie_ui on browser using relative path
file:///{Path}/movie_ui/index.html
	-movieService_9081
	-reviewService_9083 on dcoker /STS run

2) Use the dashbord of Movie



